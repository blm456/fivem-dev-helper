version "1.0.0"
author "blm456"
description "Builds resources with webpack. To learn more: https://webpack.js.org"

dependency "yarn"
server_script "webpack_builder.js"

fx_version "adamant"
game "common"